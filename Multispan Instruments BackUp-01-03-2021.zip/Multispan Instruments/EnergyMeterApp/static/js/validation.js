const form = document.getElementById('form');
const uname = document.getElementById('name');
const email = document.getElementById('emailId');
const phone = document.getElementById('contect_number');
const account_hold_type = document.getElementById('account_hold_type');
const password = document.getElementById('password');
const confirm_password = document.getElementById('confirm_password');

//add event
form.addEventListener('submit', (event) => {
    event.preventDefault();
    validate();
})
//more email validate
const isEmail = (email_idVal) => {
    var atSymbol = email_idVal.indexOf("@");
    if (atSymbol < 1) return false;
    var dot = email_idVal.lastIndexOf(".");
    if(dot<=atSymbol+2) return false;
    if(dot===email_idVal.length-1) return false;
    return true;
}
//define the validate function
const validate = () => {
    const user_nameVal = uname.value.trim();
    const email_idVal = email.value.trim();
    const phone_noVal = phone.value.trim();
    const account_holder_typeVal = account_hold_type.value.trim();
    const passwordVal = password.value.trim();
    const cpasswordVal = confirm_password.value.trim();
    //user name
    if (user_nameVal === "") {
        setErrormsg(user_nameVal, 'username cannot be blank');
    } else if (user_nameVal.length <= 3) {
        setErrormsg(user_nameVal, 'username min 3 char');
    } else {
        setSuccessMsg(user_nameVal)
    }

    //Email_id
    if (email_idVal === "") {
        setErrormsg(email_idVal, 'email cannot be blank');
    } else if (!isEmail(email_idVal)) {
        setErrormsg(email_idVal, 'email min 3 char');
    } else {
        setSuccessMsg(email_idVal)
    }
}