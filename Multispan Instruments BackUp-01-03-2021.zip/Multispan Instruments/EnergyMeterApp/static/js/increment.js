
var voltage = 20;
var current = 50;
setInterval(function() {
    current = current + 0.52 ;
    voltage = voltage + 0.32;
    current++;
   //console.info(tsmin);
   voltage++;
   var vol = voltage.toFixed(4);
   var curr = current.toFixed(4);
   document.getElementById("voltage").innerHTML = vol +"V";
   document.getElementById("current").innerHTML = curr ;
}, 3000);

function getdata(){
    url = "http://127.0.0.1:8000/api/deviceinfolist/";
    fetch(url).then((response)=>{
        return response.json();
    }).then((data)=>{
        console.log(data);
    })
}