function getdata(){
    url = "http://127.0.0.1:8000/api/deviceinfolist/";
    fetch(url).then((response)=>{
        return response.json();
    }).then((data)=>{
        console.log(data);
    })
}

setInterval(getdata,10000)