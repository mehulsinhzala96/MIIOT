from django.contrib.sites.shortcuts import get_current_site
from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.views import View
from django.core import mail
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.urls import reverse
from EnergyMeterApp.authentication.utils import account_activation_token


class RequestPasswordResetEmail(View):
    def get(self, request):
        return render(request,'resetpassword.html')

    def post(self, request):
        connection = mail.get_connection()
        connection.open()
        postData = request.POST
        email = postData.get('resetEmail')
        userdata = UserProfile.get_user_by_email(email)
        
        if userdata.isExist:
            print("pk of user : ", userdata.pk)
            uidb64 = urlsafe_base64_encode(force_bytes(userdata.pk))
            print("pk of user : ", uidb64)
            domain = get_current_site(request).domain
            link = reverse('reset-user-password', kwargs={'uidb64': uidb64, 'token': account_activation_token.make_token(userdata)})
            reset_url = 'http://'+domain+link
            print("link : ", reset_url)
            senderemail = 'mehulsinhzala245@gmail.com'
            email_subject = 'Reset Password'
            email_body = 'Hi there, Please click link below to reset your password\n'+reset_url
            reset_psssword_email = mail.EmailMessage(email_subject,email_body,senderemail,[email],connection=connection)
            reset_psssword_email.send(fail_silently=False) # Send the email
            return render(request, 'resetpassword.html')
