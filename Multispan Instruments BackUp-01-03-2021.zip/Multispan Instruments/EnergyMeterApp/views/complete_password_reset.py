from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.views import View
from django.utils.encoding import force_text
from django.utils.http import urlsafe_base64_decode
from EnergyMeterApp.authentication.utils import account_activation_token


class CompletePasswordReset(View):
    def get(self, request, uidb64, token):
        context = {
            'uidb64': uidb64,
            'token': token,
        }
        try:
            user_id = force_text(urlsafe_base64_decode(uidb64))
            user = UserProfile.objects.get(pk=user_id)
            if not account_activation_token.check_token(user,token):
                return render(request, 'resetpassword.html',{'warningMsg': 'Password reset link expired,please request a new one!!'})
        except Exception as ex:
            pass
        return render(request, 'newpassword.html', context)

    def post(self, request, uidb64, token):
        error_message = None
        context = {
            'uidb64': uidb64,
            'token': token,
        }
        postData = request.POST
        password1 = postData.get('resetpassword')
        password2 = postData.get('confirm_resetpass')

        if password1 != password2:
            error_message = 'password do not match!'
            return render(request, 'newpassword.html',context)

        if len(password1) < 6:
            error_message = 'password too short!'
            return render(request, 'newpassword.html', context)
        try:
            id = force_text(urlsafe_base64_decode(uidb64))
            user = UserProfile.objects.get(pk=id)
            user.password = password1
            user.save()
            return render(request, 'login.html', {'data': 'Password reset successfully'})
        except Exception as ex:
            pass
        return render(request, 'newpassword.html', context)