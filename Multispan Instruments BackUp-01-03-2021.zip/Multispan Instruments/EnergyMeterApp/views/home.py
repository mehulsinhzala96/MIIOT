from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.views import View


class HomeView(View):
    def get(self, request):

        if request.session.get('email') == None:
            return redirect('login')

        if request.session.get('email'):
            email = request.session.get('email')
            print(email)
            user_id = request.session.get('user_id')
            user_info = UserProfile.get_all_user()
            data = {}
            data['users'] = user_info
            return render(request, "admin-dashbord.html", data)

       