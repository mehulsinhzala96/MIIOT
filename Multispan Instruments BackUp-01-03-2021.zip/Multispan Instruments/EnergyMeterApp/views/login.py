from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.views import View

class LoginView(View):
    def get(self, request):
        return render(request, "login.html")

    def post(self, request):
        logindata = {}
        validation_message = None
        warning_message = None
        email = request.POST.get('email')
        password = request.POST.get('password')
        deviceuser = UserProfile.get_user_by_email(email)
        print(deviceuser)
        if deviceuser == False:
            validation_message = 'Email or password invalid !!'
        else:
            useremail = deviceuser.email
            userpassword = deviceuser.password
            user_is_active = deviceuser.is_active
            if useremail == email and userpassword == password:
                if user_is_active == True:
                    request.session['user_id'] = deviceuser.id
                    request.session['user_name'] = deviceuser.name
                    request.session['email'] = deviceuser.email
                    return redirect('home')
                else:
                    warning_message = 'Please verify your email account to login!!'
            else:
                validation_message = 'Email or password invalid !!'

        logindata['validationMsg'] = validation_message
        logindata['warningMsg'] = warning_message
        return render(request, 'login.html', logindata)
        
def logout(request):
    request.session.clear()
    return redirect('login')