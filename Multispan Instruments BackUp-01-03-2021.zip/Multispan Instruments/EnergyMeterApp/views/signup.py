from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.core import mail
from django.views import View
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.contrib.sites.shortcuts import get_current_site
from django.urls import reverse
from EnergyMeterApp.authentication.utils import account_activation_token

class SignUpView(View):
    def get(self,request):
        return render(request, 'signup.html')

    def post(self,request):
        connection = mail.get_connection()
        connection.open()
        postData = request.POST
        name = postData.get('name')
        email = postData.get('email')
        phone = postData.get('contect_number')
        type_account_holder = postData.get('account_hold_type')
        password = postData.get('password')
        confirm_password = postData.get('confirm_password')

        # validation
        value = {
            'name': name,
            'email': email,
            'phone': phone,
            'type_account_holder': type_account_holder,
        }
        error_message = None
        userdata = UserProfile(name=name, email=email, mobile_number=phone,account_holder_type=type_account_holder, password=password)
        userdata.is_active = False
        if not name:
            error_message = 'User Name Required!!'
        elif len(name) < 5:
            error_message = "UserName Must be 5 char long or more!!"
        elif not email:
            error_message = 'Email Address Required!!'
        elif len(email) < 5:
            error_message = "Email Address Must be 5 char long or more!!"
        elif not phone:
            error_message = 'Contact Number Required!!'
        elif len(phone) < 10:
            error_message = "Contact Number Must be 10 digit long!!"
        elif not type_account_holder:
            error_message = 'Please Select Account Holder Type!!'
        elif not password:
            error_message = 'Password Required!!'
        elif len(password) < 6:
            error_message = "Password Must be 6 char long!!"
        elif userdata.isExist():
            error_message = "Email Address Already Registered!!"
        elif not confirm_password:
            error_message = "Please confirm your password!!"
        elif password != confirm_password:
            error_message = "Password don't match"

        if not error_message:
            userdata.register()
            print("key : ",userdata.pk)
            uidb64 = urlsafe_base64_encode(force_bytes(userdata.pk))
            print("pk while register : ", uidb64)
            domain = get_current_site(request).domain
            link = reverse('activate', kwargs={'uidb64': uidb64, 'token': account_activation_token.make_token(userdata)})
            active_url = 'http://'+domain+link
            print("link : ", active_url)
            senderemail = 'mehulsinhzala245@gmail.com'
            email_subject = 'Active Your Account'
            email_body = 'Hi '+userdata.name+', Please use this link to verify your account\n'+active_url
            email1 = mail.EmailMessage(email_subject,email_body,senderemail,[email],connection=connection)
            email1.send(fail_silently=False) # Send the email

            return render(request, 'signup.html',{'data': 'Your account created successfully, please verify your email account to login'})
        else:
            data = {'error': error_message, 'values': value}
            return render(request, 'signup.html', data)