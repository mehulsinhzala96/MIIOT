from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.views import View
from django.utils.encoding import force_text
from django.utils.http import urlsafe_base64_decode
from EnergyMeterApp.authentication.utils import account_activation_token

class VerificationView(View):
    def get(self, request, uidb64, token):
        try:
            id = force_text(urlsafe_base64_decode(uidb64))
            print("id while varification : ", id)
            user = UserProfile.objects.get(pk=id)
            if not account_activation_token.check_token(user, token):
                return render(request, 'login.html',{'warningMsg': 'User Account already activated, Please Login to your account'})
            if user.is_active:
                return redirect('login')
            user.is_active = True
            user.save()
            return render(request, 'login.html',{'data': 'Account activated successfully'})
            # return redirect('login')
        except Exception as ex:
            pass
        return render(request, 'login.html',{'data': 'Account activated successfully'})