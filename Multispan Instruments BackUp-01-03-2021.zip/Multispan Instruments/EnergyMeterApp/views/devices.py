from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.views import View

class DevicesView(View):
    def get(self,request):
        return render(request,'devices.html')