from django.shortcuts import redirect, render
from EnergyMeterApp.models import UserProfile
from django.views import View

class OrganizationView(View):
    def get(self,request):
        return render(request,'organization.html')