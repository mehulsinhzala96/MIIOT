from django import forms
from django.contrib.auth.models import User
from django.db import models
from django.forms import fields
from EnergyMeterApp.models import Profile

class ProfileForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta():
        models=User
        fields=('username','password','email')
    
class InfoProfile(forms.ModelForm):
    class Meta():
        model=Profile
        fields=('')