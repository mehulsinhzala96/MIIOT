from django.contrib import admin
from EnergyMeterApp.models import UserProfile
# Register your models here.

admin.site.register(UserProfile)