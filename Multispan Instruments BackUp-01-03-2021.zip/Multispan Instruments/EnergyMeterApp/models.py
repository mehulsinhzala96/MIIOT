from django.db import models
# Create your models here.

# class AccountHolderType(models.Model):
#     title = models.CharField(max_length=50)

#     def __str__(self):
#         return self.name

class UserProfile(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=254)
    mobile_number = models.CharField(max_length=15)
    account_holder_type = models.CharField(max_length=50)
    password = models.CharField(max_length=254)
    is_active = models.BooleanField(default=False)

    def isExist(self):
        if UserProfile.objects.filter(email=self.email):
            return True
        return False

    def __str__(self):
        return self.name
        
    def register(self):
        self.save()

    @staticmethod
    def get_user_by_email(email):
        try:
            return UserProfile.objects.get(email=email)
        except:
            return False

    def get_all_user():
        return UserProfile.objects.all()


class SubUserProfile(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=254)
    mobile_number = models.CharField(max_length=15)
    position = models.CharField(max_length=50)
    password = models.CharField(max_length=254)
    user_role = models.BooleanField(default=False)