from django.apps import AppConfig


class EnergymeterappConfig(AppConfig):
    name = 'EnergyMeterApp'
