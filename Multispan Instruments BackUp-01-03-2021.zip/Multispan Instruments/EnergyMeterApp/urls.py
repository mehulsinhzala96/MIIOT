from django.urls import path
from EnergyMeterApp.views.home import HomeView
from EnergyMeterApp.views.login import LoginView,logout
from EnergyMeterApp.views.signup import SignUpView
from EnergyMeterApp.views.users import UserView
from EnergyMeterApp.views.verification import VerificationView
from EnergyMeterApp.views.request_password_reset_email import RequestPasswordResetEmail
from EnergyMeterApp.views.complete_password_reset import CompletePasswordReset
from EnergyMeterApp.views.organization import OrganizationView
from EnergyMeterApp.views.devices import DevicesView

urlpatterns = [
    path('login',LoginView.as_view(),name="login"),
    path('logout/',logout, name="logout"),
    path('registration',SignUpView.as_view(),name="registration"),
    path('',HomeView.as_view(),name="home"),
    path('users',UserView.as_view(),name="users"),
    path('authentication/activate/<uidb64>/<token>',VerificationView.as_view(),name="activate"),
    path('set-new-password/<uidb64>/<token>',CompletePasswordReset.as_view(),name="reset-user-password"),
    path('request-reset-link',RequestPasswordResetEmail.as_view(),name="request-reset-link"),
    path('organization',OrganizationView.as_view(),name="organization"),
    path('devices',DevicesView.as_view(),name="devices"),
]